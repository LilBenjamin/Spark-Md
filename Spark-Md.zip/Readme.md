<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## Spark-Md V1.0.0 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<div align="center">
  <a href="https://git.io/typing-svg"><img src="http://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&center=true&width=435&lines=SPARK+MD;A+Simple+WHATSAPP+BOT+Made+with+%F0%9F%A4%8D" alt="Typing SVG" /></a>
  </p>
<div align="center">

| [![Supreme-Md](https://telegra.ph/file/201479b521f3c8c245147.jpg?lenght=50width=50)](https://github.com/Sepreme-Md)|
|----|

<p align="center">
 <a href="https://git.io/typing-svg"><img src="http://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&width=435&lines=A+Simple+WHATSAPP+BOT+Made+with+%F0%9F%A4%8D;SPARK+MD" alt="Typing SVG" /></a>





🔗SETUP
[**FORK**](https://github.com/Supreme-Tech-Kenya/Supreme-Md) FIRST and star 🌟 

Get SESSION ID by Pairing code or Scanning QR: 

   [**SESSION TAB**](https://supresession-c8207054b6c5.herokuapp.com/) ; <br><br>
_Copy the session ID to paste it on HEROKU

🔗 DEPLOY TO HEROKU 
 
If You Don't Have An Account On HEROKU  [**CREATE ACCOUNT NOW**](https://id.heroku.com/login) 
If You Have An Heroku Account [**DEPLOY NOW**](https://dashboard.heroku.com/new?template=https://github.com/Supreme-Tech-Kenya/Supreme-Md)

🔗 CONTRIBUTIONS

Contribution to Supreme-Md are welcome!! If you have any idea for new Features , Improvement , Bug Fixes , Feel Free to Senda DM to the provided contact below.
https://wa.me/2349024553612

🔗 THANKS TO 😊 :

<!---- [**SUPREME ALPHA**](https://wa.me/254796266758) For code Encryption. 
 [**SUPREME BENJAMIN**](https://wa.me/254769702239) For several Cmds & ideas.
[**BELTAH TECH**](https://wa.me/254114141192) For Providing a base of SUPREME-MD.---->

<!----🔗 TO JOIN OUR WHATSAPP CHANNEL.
[**JOIN**](https://whatsapp.com/channel/0029VaeLIpA6mYPQ5dmuVe0C)

🔗 TO JOIN OUR UPDATES GROUP.
[**JOIN**](https://chat.whatsapp.com/Lq3VFHeqKXI5GNy3ZmadRG)

🔗 TO JOIN OUR TELEGRAM CHANNEL.
[**JOIN**](https://t.me/SupremeTech254) 

<!---- 🔗 DEVELOPERS OF Supreme-Md             

[**SUPREME ALPHAA**](https://wa.me/254719846879)                                                             

[**SUPREME BENJAMIN**](https://wa.me/254769702239)    ----->                                                                                                                                                                                                                                                                                                                                                                                 
